

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import servletexamples.DBConnect;

@WebServlet("/createaccount")
public class createaccountServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get user input from the form
        String email = request.getParameter("email");
        String newUsername = request.getParameter("newUsername");
        String newPassword = request.getParameter("newPassword");
        String securityAnswer = request.getParameter("securityAnswer"); // Added this line

        // Oracle database connection details

        try {
            // Load the Oracle JDBC driver
            Connection con = DBConnect.connect();

            // Create a SQL statement to insert the user data into a table
            String sql = "INSERT INTO users (email, username, password, security_answer) VALUES (?, ?, ?, ?)"; // Modified SQL query
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, newUsername);
            preparedStatement.setString(3, newPassword);
            preparedStatement.setString(4, securityAnswer); // Added this line

            // Execute the SQL statement
            preparedStatement.executeUpdate();

            // Close the database connection
            con.close();
         // Redirect the user to a success page or another appropriate page
            response.sendRedirect("registration_success.html");
       
        } catch (Exception e) {
            e.printStackTrace();
            // Handle any exceptions that occur during the database insertion
        }

         }
}
