

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import servletexamples.DBConnect;

import java.sql.*;

/**
 * Servlet implementation class UserLogin
 */
@WebServlet("/UserLogin")
public class UserLoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get user input from the form
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Oracle database connection details
        
        boolean isAuthenticated = false; // Flag to track authentication status

        try {
            // Load the Oracle JDBC driver
        	Connection con = DBConnect.connect();

            // Create a SQL statement to check if the user credentials exist in the database
            String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            // Execute the SQL query
            ResultSet resultSet = preparedStatement.executeQuery();

            // If a row is returned, the user is authenticated
            if (resultSet.next()) {
                isAuthenticated = true;
            }

            // Close the database connection
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            // Handle any exceptions that occur during database operations
        }

        // Based on the authentication result, redirect the user
        if (isAuthenticated) {
            // Redirect to a success page or the user's profile
            response.sendRedirect("success.html");
        } else {
            // Redirect to a login error page or display an error message
            response.sendRedirect("Login_error.html");
        }
    }
}
