

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import servletexamples.DBConnect;

@WebServlet("/process_recovery")
public class PasswordRecoveryServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get user input from the form
        String username = request.getParameter("username");
        String securityAnswer = request.getParameter("securityAnswer");

        // Database connection and validation status
        Connection con = null;
        boolean isValid = false;

        try {
            // Load the Oracle JDBC driver
        	 con = DBConnect.connect();

            // Create a SQL statement to check if the user credentials exist in the database
            String sql = "SELECT * FROM users WHERE username = ? AND security_answer = ?";
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, securityAnswer); // Use 2 for the second parameter

            // Execute the SQL query
            ResultSet resultSet = preparedStatement.executeQuery();

            // If a row is returned, the details are valid
            if (resultSet.next()) {
                isValid = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Handle any exceptions that occur during database operations
        } finally {
            try {
                if (con != null) {
                    con.close(); // Close the database connection in the finally block
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (isValid) {
            // Redirect to a success page
            response.sendRedirect("password_reset.html");
        } else {
            // Display an error message
            response.getWriter().println("Invalid details. Please try again.");
        }
    }
}