

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class FileUploadServlet
 * 
 */
@MultipartConfig 
public class FileUploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FileUploadServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 String jdbcUrl = "jdbc:mysql://localhost:3306/vvit";
	        String dbUser = "root";
	        String dbPassword = "131824";
		
		try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            // Get the file part from the request
            Part filePart = request.getPart("file");

            // Get the next file number from the database
            int nextFileNumber = getNextFileNumber(connection);

            // Construct the filename with the assigned number
            String fileName = "File" + nextFileNumber + "_" + getFileName(filePart);

            // Get the InputStream of the file
            InputStream fileContent = filePart.getInputStream();

            // Store file information in the database
            String sql = "INSERT INTO files (fileid,filename, file_content) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            	preparedStatement.setInt(1,nextFileNumber);
                preparedStatement.setString(2, fileName);
                preparedStatement.setBinaryStream(3, fileContent);

                preparedStatement.executeUpdate();
            }

            response.getWriter().println("File uploaded successfully! Assigned file number: " + nextFileNumber);
        } catch (Exception e) {
            throw new ServletException("Database error", e);
        }
    }

    // Utility method to extract file name from Part
    private String getFileName(final Part part) {
        for (String content : part.getHeader("content-disposition").split(";")) {
            if (content.trim().startsWith("filename")) {
                return content.substring(content.indexOf('=') + 1).trim().replace("\"", "");
            }
        }
        return null;
    }

    // Utility method to get the next file number from the database
    private int getNextFileNumber(Connection connection) throws SQLException   {
        String sql = "SELECT MAX(fileid) FROM files";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            if (resultSet.next()) {
                return resultSet.getInt(1) + 1;
            } else {
                return 1; // If no files exist yet, start from 1
            }
        }
    }
}



	
