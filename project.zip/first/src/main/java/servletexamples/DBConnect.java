package servletexamples;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {

	public static Connection connect() throws SQLException{
		// TODO Auto-generated method stub
		String jdbcUrl = "jdbc:mysql://localhost:3306/vvit";
        String dbUser = "root";
        String dbPassword = "131824";
        
			Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
			return connection;
				
		
	}

	
}
