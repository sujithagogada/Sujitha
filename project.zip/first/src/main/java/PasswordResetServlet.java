

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import servletexamples.DBConnect; // Adjust the import as per your package structure

@WebServlet("/PasswordResetServlet")
public class PasswordResetServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get user input from the form
        String username = request.getParameter("username");
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");

        // Perform password validation
        if (!newPassword.equals(confirmPassword)) {
            // Passwords do not match, handle the error (e.g., display an error message)
            PrintWriter out = response.getWriter();
            out.println("Passwords do not match. Please try again.");
            return;
        }

        // Modify the password in the database
        try {
            // Load the database connection
            Connection con = DBConnect.connect(); // Replace with your DB connection code

            // Update the password in the database using a SQL query
            String sql = "UPDATE users SET password = ? WHERE username = ?";
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            preparedStatement.setString(1, newPassword);
            preparedStatement.setString(2, username);
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                // Password updated successfully, you can redirect to a success page
                response.sendRedirect("password_reset_success.html");
            } else {
                // Handle the case where the username does not exist in the database
                response.sendRedirect("password_reset_error.html");
            }

            // Close the database connection
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            // Handle any exceptions that occur during database operations
        }
    }
}
